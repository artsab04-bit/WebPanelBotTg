# Изменения: Добавлен импорт sqlite3 и APP_PATHS для list_supports. Улучшена обработка ошибок. Добавлены уведомления о добавлении/удалении специалистов админам.
from telebot import TeleBot
from telebot.types import CallbackQuery, Message
from core.db import User
from core.markups import main_menu_markup
from data.TEXT_MESSAGES import WELCOME
import sqlite3
from core.config import APP_PATHS

def setup_inline_callbacks(bot: TeleBot):
    @bot.callback_query_handler(func=lambda call: call.data.startswith("lang:"))
    def handle_language(call: CallbackQuery):
        user_id = call.from_user.id
        language = call.data.split(":")[1]
        user_obj = User(user_id)
        try:
            user_obj.set_language(language)
            callback_text = "Язык изменен на RU" if language == "ru" else "Language set to EN"
            bot.answer_callback_query(call.id, callback_text)
            bot.edit_message_reply_markup(
                call.message.chat.id,
                call.message.message_id,
                reply_markup=None
            )
            bot.send_message(
                user_id,
                WELCOME[language],
                reply_markup=main_menu_markup(language)
            )
            user_obj.set_state("main_menu")
        finally:
            user_obj.exit()

    @bot.callback_query_handler(func=lambda call: call.data == "add_support")
    def add_support(call: CallbackQuery):
        bot.answer_callback_query(call.id, "Введите ID специалиста для добавления.")
        bot.register_next_step_handler_by_chat_id(call.message.chat.id, process_add_support)

    def process_add_support(message: Message):
        try:
            user_id = int(message.text)
            conn = sqlite3.connect(APP_PATHS["database"])
            cursor = conn.cursor()
            cursor.execute("INSERT OR REPLACE INTO specialists (user_id, role) VALUES (?, ?)", (user_id, 'specialist'))
            conn.commit()
            conn.close()
            bot.send_message(message.chat.id, f"Специалист {user_id} добавлен.")
            # Уведомление админам
            bot.send_message(GROUP_ID, f"Новый специалист добавлен: {user_id}")
        except ValueError:
            bot.send_message(message.chat.id, "Неверный ID. Введите число.")
        except Exception as e:
            bot.send_message(message.chat.id, f"Ошибка: {e}")

    @bot.callback_query_handler(func=lambda call: call.data == "remove_support")
    def remove_support(call: CallbackQuery):
        bot.answer_callback_query(call.id, "Введите ID специалиста для удаления.")
        bot.register_next_step_handler_by_chat_id(call.message.chat.id, process_remove_support)

    def process_remove_support(message: Message):
        try:
            user_id = int(message.text)
            conn = sqlite3.connect(APP_PATHS["database"])
            cursor = conn.cursor()
            cursor.execute("DELETE FROM specialists WHERE user_id = ?", (user_id,))
            conn.commit()
            conn.close()
            bot.send_message(message.chat.id, f"Специалист {user_id} удален.")
            # Уведомление админам
            bot.send_message(GROUP_ID, f"Специалист удален: {user_id}")
        except ValueError:
            bot.send_message(message.chat.id, "Неверный ID. Введите число.")
        except Exception as e:
            bot.send_message(message.chat.id, f"Ошибка: {e}")

    @bot.callback_query_handler(func=lambda call: call.data == "list_supports")
    def list_supports(call: CallbackQuery):
        try:
            conn = sqlite3.connect(APP_PATHS["database"])
            cursor = conn.cursor()
            cursor.execute("SELECT user_id, role FROM specialists")
            supports = cursor.fetchall()
            response = "Список специалистов:\n"
            for supp in supports:
                response += f"ID: {supp[0]}, Role: {supp[1]}\n"
            bot.send_message(call.message.chat.id, response)
            conn.close()
        except Exception as e:
            bot.send_message(call.message.chat.id, f"Ошибка: {e}")
