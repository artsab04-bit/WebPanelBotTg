import datetime
import sqlite3
from ..Logers import LoggingConfigurations
from ..config import APP_PATHS as PATH

logger = LoggingConfigurations.db

class AdminRate:
    def __init__(self, adminID: int, user_id: str = None):
        self.connection = sqlite3.connect(PATH["database"])
        self.adminID = adminID
        self.uid = user_id

    def get_rate(self):
        cursor = self.connection.cursor()
        cursor.execute("SELECT * FROM AdminRate WHERE id = ?", (self.adminID,))
        result = cursor.fetchall()
        cursor.close()
        return result if result else None

    def new_rate(self, rate: int):
        date = datetime.datetime.now().strftime("%d-%m-%Y %H:%M")
        cursor = self.connection.cursor()
        cursor.execute("INSERT INTO AdminRate (id, rate, date, uid) VALUES (?, ?, ?, ?)",
                       (self.adminID, rate, date, self.uid))
        self.connection.commit()
        cursor.close()

    def clean_all_rates(self):
        cursor = self.connection.cursor()
        cursor.execute("DELETE FROM AdminRate")
        self.connection.commit()
        cursor.close()

    def clean_rates_by_id(self, admin_id: int):
        cursor = self.connection.cursor()
        cursor.execute("DELETE FROM AdminRate WHERE id = ?", (admin_id,))
        self.connection.commit()
        cursor.close()

    def replace_rates_by_id(self, rate: int, admin_id: int):
        cursor = self.connection.cursor()
        cursor.execute("UPDATE AdminRate SET rate = ? WHERE id = ?", (rate, admin_id))
        self.connection.commit()
        cursor.close()

    def __del__(self):
        self.connection.close()
