import sqlite3
from ..config import APP_PATHS as PATH
from ..Logers import LoggingConfigurations

logger = LoggingConfigurations.db

class Settings:
    def __init__(self):
        self.conn = sqlite3.connect(PATH["database"], timeout=20)
        self.conn.execute("PRAGMA journal_mode=WAL")
        self._create_table()

    def _create_table(self):
        try:
            self.conn.execute("""
                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                )
            """)
            self.conn.commit()
        except sqlite3.Error as e:
            logger.error(f"Ошибка создания таблицы settings: {e}")

    def get(self, key: str):
        try:
            cursor = self.conn.cursor()
            cursor.execute("SELECT value FROM settings WHERE key = ?", (key,))
            result = cursor.fetchone()
            return result[0] if result else None
        except sqlite3.Error as e:
            logger.error(f"Ошибка получения настройки {key}: {e}")
            return None
        finally:
            cursor.close()

    def set(self, key: str, value: str):
        try:
            cursor = self.conn.cursor()
            cursor.execute(
                "INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)",
                (key, value)
            )
            self.conn.commit()
            logger.info(f"Настройка {key} обновлена: {value}")
        except sqlite3.Error as e:
            logger.error(f"Ошибка обновления настройки {key}: {e}")
        finally:
            cursor.close()

    def __del__(self):
        try:
            self.conn.commit()
            self.conn.close()
            logger.debug("Соединение с базой данных закрыто (settings)")
        except:
            pass
