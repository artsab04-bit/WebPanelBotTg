import sqlite3
from datetime import datetime
from ..config import APP_PATHS as PATH
from ..Logers import LoggingConfigurations

logger = LoggingConfigurations.db

class BlackList:
    def __init__(self):
        self.connection = sqlite3.connect(PATH["database"], timeout=20)
        self._create_table()

    def _create_table(self):
        try:
            self.connection.execute("""
                CREATE TABLE IF NOT EXISTS blacklist (
                    id INTEGER PRIMARY KEY,
                    addedby INTEGER NOT NULL,
                    reason TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            self.connection.commit()
        except sqlite3.Error as e:
            logger.error(f"Ошибка создания таблицы blacklist: {e}")
            raise

    def is_blacklisted(self, user_id: int) -> bool:
        cursor = self.connection.cursor()
        cursor.execute("SELECT 1 FROM blacklist WHERE id = ?", (user_id,))
        result = cursor.fetchone() is not None
        cursor.close()
        return result

    def get_ban_info(self, user_id: int) -> tuple:
        cursor = self.connection.cursor()
        cursor.execute("SELECT id, addedby, reason, created_at FROM blacklist WHERE id = ?", (user_id,))
        result = cursor.fetchone()
        cursor.close()
        return result

    def add_to_blacklist(self, user_id: int, admin_id: int, reason: str = None) -> bool:
        current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        cursor = self.connection.cursor()
        cursor.execute("INSERT OR REPLACE INTO blacklist (id, addedby, reason, created_at) VALUES (?, ?, ?, ?)",
                       (user_id, admin_id, reason, current_time))
        self.connection.commit()
        cursor.close()
        return True

    def remove_from_blacklist(self, user_id: int) -> bool:
        cursor = self.connection.cursor()
        cursor.execute("DELETE FROM blacklist WHERE id = ?", (user_id,))
        result = cursor.rowcount > 0
        self.connection.commit()
        cursor.close()
        return result

    def __del__(self):
        self.connection.close()
