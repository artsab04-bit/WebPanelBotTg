# Изменения: Фикс set_role для обновления specialists таблицы вместо users. Добавлен created_at с default current_timestamp. Улучшена обработка None в create.
import sqlite3
from telebot.types import Message
from ..Logers import LoggingConfigurations
from ..types import UserData
from ..config import APP_PATHS as PATH
import time
from datetime import datetime
logger = LoggingConfigurations.db

class User:
    def __init__(self, uid: int = None, username: str = None, ticketID: int = None, full_data: Message = None):
        self.connection = sqlite3.connect(PATH["database"], timeout=20)
        self.uid = uid
        self.username = username
        self.ticketID = ticketID
        self.userdata = None
        if self.uid is not None:
            self._get_by_uid()
        elif self.ticketID is not None:
            self._get_by_ticket()

    def _get_by_uid(self) -> UserData:
        cursor = self.connection.cursor()
        cursor.execute("SELECT * FROM users WHERE id = ?", (self.uid,))
        result = cursor.fetchone()
        cursor.close()
        if result:
            self.userdata = UserData(*result)
        else:
            self.create()
        return self.userdata

    def _get_by_ticket(self) -> UserData:
        cursor = self.connection.cursor()
        cursor.execute("SELECT * FROM users WHERE ticketID = ?", (self.ticketID,))
        result = cursor.fetchone()
        cursor.close()
        if result:
            self.userdata = UserData(*result)
        return self.userdata

    def create(self) -> UserData:
        current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        cursor = self.connection.cursor()
        cursor.execute("""
            INSERT INTO users (id, username, ticketID, language, state, last_button_time, role, last_message_time, created_at, selected_topic)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (self.uid, self.username or "NONE_USER", -99999, None, "main_menu", 0, "user", 0, current_time, None))
        self.connection.commit()
        cursor.close()
        self.userdata = UserData(self.uid, self.username, -99999, None, "main_menu", 0, "user", 0, current_time, None)
        return self.userdata

    def set_language(self, lang: str) -> UserData:
        cursor = self.connection.cursor()
        cursor.execute("UPDATE users SET language = ? WHERE id = ?", (lang, self.uid))
        self.connection.commit()
        cursor.close()
        self.userdata.language = lang
        return self.userdata

    def set_ticket(self, ticketID: int):
        cursor = self.connection.cursor()
        cursor.execute("UPDATE users SET ticketID = ? WHERE id = ?", (ticketID, self.uid))
        self.connection.commit()
        cursor.close()
        self.userdata.ticketID = ticketID

    def set_state(self, state: str):
        cursor = self.connection.cursor()
        cursor.execute("UPDATE users SET state = ? WHERE id = ?", (state, self.uid))
        self.connection.commit()
        cursor.close()
        self.userdata.state = state

    def set_last_button_time(self, timestamp: int):
        cursor = self.connection.cursor()
        cursor.execute("UPDATE users SET last_button_time = ? WHERE id = ?", (timestamp, self.uid))
        self.connection.commit()
        cursor.close()
        self.userdata.last_button_time = timestamp

    def set_role(self, role: str):
        cursor = self.connection.cursor()
        cursor.execute("INSERT OR REPLACE INTO specialists (user_id, role) VALUES (?, ?)", (self.uid, role))
        self.connection.commit()
        cursor.close()
        self.userdata.role = role

    def get_role(self, user_id: int):
        cursor = self.connection.cursor()
        cursor.execute("SELECT role FROM specialists WHERE user_id = ?", (user_id,))
        result = cursor.fetchone()
        cursor.close()
        return result[0] if result else "user"


    def set_selected_topic(self, topic: str):
        cursor = self.connection.cursor()
        cursor.execute("UPDATE users SET selected_topic = ? WHERE id = ?", (topic, self.uid))
        self.connection.commit()
        cursor.close()
        self.userdata.selected_topic = topic

    def set_last_message_time(self, timestamp: int):
        cursor = self.connection.cursor()
        cursor.execute("UPDATE users SET last_message_time = ? WHERE id = ?", (timestamp, self.uid))
        self.connection.commit()
        cursor.close()
        self.userdata.last_message_time = timestamp

    def exit(self):
        self.connection.commit()
        self.connection.close()

    def __del__(self):
        try:
            self.connection.commit()
            self.connection.close()
        except:
            pass
