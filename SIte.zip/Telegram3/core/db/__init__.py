from .user import User
from .ticket import Ticket  # Убедитесь что файл ticket.py существует
from .rate import AdminRate
from .messages import Messages
from .blacklist import BlackList
from .setup import setup_database
from .settings import Settings

# Явно указываем какие объекты будут доступны при импорте из core.db
__all__ = [
    'User',
    'Ticket',  # Добавляем Ticket в экспортируемые объекты
    'AdminRate',
    'Messages', 
    'BlackList',
    'setup_database'
]
