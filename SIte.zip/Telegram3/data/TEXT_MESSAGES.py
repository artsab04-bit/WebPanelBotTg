#USER
HELLO = {
    "ru": """Добро пожаловать, я бот поддержки Hyper.
Для того что-бы написать администратору, просто напиши сообщение с описанием проблемы и тикет создастся автоматически, так-же желательно прикрепить изображение или видео.
""",
    "en": """
Welcome, I am the Hyper support bot.
To write to an administrator, simply write a message describing the problem and a ticket will be created automatically, it is also advisable to attach an image or video.
"""
}
CREATED = {
    "ru": """
Тикет создан!\nПожалуйста, ожидайте ответа администратора.\nВсе ваши сообщения ниже будут отправлены администратору.
    """,
    "en": """
Ticket created!\nPlease wait for the administrator's response.\nAll your messages below will be sent to the administrator.
    """
}
WELCOME = {
    "ru": "Добро пожаловать в бота поддержки Hyper. Выберите действие:",
    "en": "Welcome to the Hyper support bot. Choose an action:"
}
REMINDER = {
    "ru": "Пожалуйста, выберите одну из кнопок.",
    "en": "Please select one of the buttons."
}
CHAT_LINK = {
    "ru": "Наш чат пользователей - https://t.me/hypercollisionfun",
    "en": "Our user chat - https://t.me/hypercollisionfun"
}
AUTO_CLOSE = {
    "ru": "Ваш тикет закрыт из-за истечения времени ответа (24 часа). Если проблема осталась, создайте новый тикет и опишите проблему заново — история переписки не сохраняется.",
    "en": "Your ticket has been closed due to response timeout (24 hours). If the issue persists, create a new ticket and describe the problem again — chat history is not saved."
}
MANUAL_CLOSE = {
    "ru": "🔒Ваш тикет #{ticket_id} закрыт! Если у вас есть какие-либо вопросы, пожалуйста, создайте тикет и опишите вашу проблему.\nПожалуйста запомните номер тикета, если вы хотите задать вопрос по старому вопросу.",
    "en": "🔒Your ticket #{ticket_id} is closed! If you have any questions, please create a ticket and describe your issue.\nPlease remember the ticket number if you want to ask about the previous issue."
}
FORM = {
    "ru": """
Перед отправкой заявки посетите данный раздел: https://hyper-software.gitbook.io/hyper/hyper/fix-errors-with-launch
‼️Заполните форму ниже:
‼️Пишите все 1 сообщением.
1. Предоставьте ваш ключ и почту с которой совершали покупку
2. О каком продукте речь (название чита + игра)
3. Опишите кратко вашу проблему
4. Предоставьте скриншоты или видео проблемы (Лучше видео)
5. Скриншот из msinfo32
Режим работы поддержки с 11:00 до 23:00 по МСК, если вы написали в нерабочее время, ваше обращение будет обработано согласно очереди.
""",
    "en": """
Before submitting a request, visit this section: https://hyper-software.gitbook.io/hyper/hyper/fix-errors-with-launch
‼️Fill out the form below:
‼️Write everything in 1 message.
1. Provide your key and the email from which you made the purchase
2. What product is it about (cheat name + game)
3. Briefly describe your problem
4. Provide screenshots or video of the problem (Video is better)
5. Screenshot from msinfo32
Support operating hours from 11:00 to 23:00 MSK, if you wrote outside working hours, your request will be processed in queue.
"""
}
NIGHT_MODE_OFF = {
    "ru": "🌙 Техническая поддержка в данный момент не работает. Ваш тикет будет обработан в рабочие часы в порядке очереди.\n\n⏳Режим работы поддержки - с 11:00 до 23:00 по МСК времени.",
    "en": "🌙 Technical support is currently unavailable. Your ticket will be processed during working hours in queue order.\n\n⏳Support is available from 11:00 a.m. to 11:00 p.m. Moscow time."
}

TOPIC_PROMPT = {
    "ru": "Выберите тему обращения:",
    "en": "Choose a topic for your request:"
}

BAN_INFO = {
    "ru": (
        "Любое использование стороннего софта в играх с античитом всегда несёт риск бана — даже если софт работал стабильно месяцами. "
        "Разработчики игр постоянно обновляют защиту, и то, что вчера было безопасно — сегодня может детектиться.\n\n"
        "Пожалуйста, заполни форму по ссылке ниже 👇\n"
        "{ban_link}\n"
        "Мы внимательно проверим все данные.\n"
        "Возможно после проверки статус чита будет изменён."
    ),
    "en": (
        "Any use of third-party software in games with anti-cheat always carries a ban risk — even if the software worked stably for months. "
        "Game developers constantly update protection, and what was safe yesterday can be detected today.\n\n"
        "Please fill out the form at the link below 👇\n"
        "{ban_link}\n"
        "We will carefully review all the data.\n"
        "The cheat status may be changed after review."
    )
}

AVERAGE_RESPONSE = {
    "ru": "Среднее время ответа технической поддержки за последние 48 часов составляет {avg_time}.",
    "en": "The average technical support response time over the last 48 hours is {avg_time}."
}

OPERATOR_PROMPT = {
    "ru": "Для связи с оператором нажмите кнопку ниже.",
    "en": "To contact an operator, press the button below."
}
